import random

# Basic Facts - Get & check user input

# To do
# Give user instructions on how to play
# Ask what kind of maths they want to do (options)
# Ask how many rounds they want (loop)
# Ask basic facts question(s)
# Check answer(s) (incorrect/correct)
# Give feedback
# Summary

# integer checker goes here
def int_check(question, low, high):
    valid = False
    while not valid:
        error = "Please enter an integer between {} and {}".format(low, high)

        try:
            response = int(input("How many questions do you wanna to do? (between {} and {}): ".format(low, high)))

            if low <= response <= high:
                return response
            else:
                print(error)
                print()
                continue

        except ValueError:
            print(error)

    print(response)

# main routine goes here

keep_going = ""
while keep_going == "":
 
  print("What kind of maths do you wanna do?")
  options = input( "'a' for addition, 's' for subtraction, and 'm' for multiplication. ")
  start = 0
  max_rounds = int_check(" ", 1, 10)

  for item in range(start, max_rounds):
    x = random.randint(1,20)
    y = random.randint(1,20)
    error = "Please select one of the options."
    if options == "a":
      start += 1
      print("{}: What is {} plus {}?".format(start, x, y))
      answer = int(input())
      if answer == (x + y):
        print("Correct!")
      else:
        print("Wrong, it's " + str(x+y) + "." )
    elif options == "s":
      start += 1
      print("{}: What is {} minus {}?".format(start, x, y))
      answer = int(input())
      if answer == (x - y):
        print("Correct!")
      else:
        print("Wrong, it's " + str(x-y) + "." )
    elif options == "m":
      start += 1
      print("{}: What is {} times {}?".format(start, x, y))
      answer = int(input())
      if answer == (x * y):
        print("Correct!")
      else:
        print("Wrong, it's " + str(x*y) + ".")
    else:
      print(error)
  
  
  keep_going = input("Again? Press enter to continue. ")

