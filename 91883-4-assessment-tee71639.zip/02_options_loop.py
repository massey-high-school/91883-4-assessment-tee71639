import random

# Asks user what kind of math questions they want to do
# Gives them question(s)
# Gets input and gives feedback

error = "Please select one of the options. 'a' for addition, 's' for subtraction, and 'm' for multiplication. "
x = random.randint(1, 20)
y = random.randint(1, 20)
print("What kind of maths do you wanna do? ")
options = input("'a' for addition, 's' for subtraction, and 'm' for multiplication. ")
if options == "a":
  print("What is " + str(x) + " plus " + str(y) + "? ")
  answer = int(input())
  if answer == (x + y):
    print("Correct!")
  else:
    print("Wrong, it's " + str(x+y) + ". ")
elif options == "s":
  print("What is " + str(x) + " minus " + str(y) + "? ")
  answer = int(input())
  if answer == (x - y):
    print("Correct!")
  else:
    print("Wrong, it's " + str(x-y) + ". ")
elif options == "m":
  print("What is " + str(x) + " times " + str(y) + "? ")
  answer = int(input())
  if answer == (x * y):
    print("Correct!")
  else:
    print("Wrong, it's " + str(x*y) + ". ")
else: print(error)
