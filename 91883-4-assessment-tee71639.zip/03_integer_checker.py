# integer checker
def int_check(question, low, high):
    valid = False
    while not valid:
        error = "Please enter an integer between {} and {}".format(low, high)

        try:
            response = int(input("How many questions do you want to do? (between {} and {}): ".format(low, high)))

            if low <= response <= high:
                return response
            else:
                print(error)
                print()

        except ValueError:
            print(error)

    print(response)
    